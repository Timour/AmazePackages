# Changelog

## 0.2.0

- Every field that moves the pigment is a wind, and the POP Solver blends them into one. Water, Motion, Moving Geometry and Curl Noise each pull pigment toward their own vectors, weighted by their strength.
- Strength Sets on the Forces tab picks what the four sliders set on their field: its Air Resistance, which is its weight in the blend (the default), or its Velocity Scale.
- Follow on the Forces tab sets how quickly pigment takes on the blend. At its default the wash looks as before; lower it for looser, swirlier pigment.
- Motion is the field a moving stroke makes. Pigment can leave its stroke and swirl.
- Motion's and Moving Geometry's fields come from their points' own velocity, at twice the Grid's Voxel Size by default, set by Voxel Scale beside Reach. On a bending, twisting sheet a frame takes about a seventh of the time it did.
- A field at 0 is switched off, and Moving Geometry is off with nothing in the third input.
- The water holds settled and dried pigment still, and the other fields move it against that hold. Set Water's Group to `@dry==0` to let dried pigment go.
- A POP Wind added in the POP network joins the blend. A POP Force has little room against it.
- The 3D Plane is gone. UV, and a Plane with Curl Noise or Motion, replace it.

## 0.1.1

- UV moves pigment over strokes whose `uv` is on their points, as it does for `uv` on their vertices.
- Strokes already moving keep their Motion on the frame another stroke lands.
- UV runs about a fifth faster on shapes that do not move.

## 0.1.0

- Watercolor POP moves its pigment in a POP network inside the node. A double-click on the node opens it, and a POP node added there acts on the pigment like any other.
- The Forces tab sets how strongly each field moves the pigment: Water, Motion, Moving Geometry and Curl Noise, each with its node's own parameters below it.
- A third input takes other geometry: as it moves, it carries the pigment near it.
- Motion carries pigment with its strokes as they move or bend, by the strokes' own `v` when they have one.
- UV runs the wash on the strokes' own UV map and moves the pigment over their surface, bent or flat.
- Strokes come from the geometry or from its colour, in every Plane.
- A stroke lays its pigment once, moving or not, at any number of steps a frame.
- Pigment has a Life Expectancy and Life Variance, and its Alpha follows the Alpha Ramp over its life.
- Border Type on the Grid tab sets what the fields give pigment outside the grid. At Streak, pigment lifted off the plane moves with the fields under it.
- Dried pigment moves under every field but the water's, and carries `dry`.
- The wash's grid grows when a stroke lands beyond it.
- Each particle's `v` is its own move, for motion blur.
- The second output carries the fields that move the pigment, Motion's as `motionvel` and Moving Geometry's as `movingvel`.
