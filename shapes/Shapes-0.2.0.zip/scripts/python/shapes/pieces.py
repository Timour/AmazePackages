"""The piece library: one unit piece per kind, built as SOP nodes inside the asset when the asset is built. Every piece fits a unit cube centred on the origin and carries `name`, the piece attribute the copy matches against the cloud's points."""

import hou

THIN = 0.1


def _kind(node, kind):
    """Names every primitive of one piece after its kind: `name` on the primitives is what Copy to Points matches a piece by ▸ sop/name Attribute + Class."""
    n = node.createOutputNode("name", "kind_" + kind)
    n.parm("attribname").set("name")
    n.parm("class").set("primitive")
    n.parm("name1").set(kind)    # Group left empty, so the naming reaches every primitive of the piece
    return n


def _box(parent, size, centre=(0, 0, 0), rotate=(0, 0, 0)):
    b = parent.createNode("box")
    b.parmTuple("size").set(size)
    b.parmTuple("t").set(centre)
    b.parmTuple("r").set(rotate)
    return b


def _tube(parent, radius, height, axis="y", cols=32, centre=(0, 0, 0)):
    t = parent.createNode("tube")
    t.parm("type").set("poly")
    t.parm("cap").set(1)
    t.parm("orient").set(axis)
    t.parm("rad1").set(radius)
    t.parm("rad2").set(radius)
    t.parm("height").set(height)
    t.parm("cols").set(cols)
    t.parmTuple("t").set(centre)
    return t


def _clip(node, origin, direction, keep="below"):
    """Cuts a closed piece by a plane and caps the cut, so the half stays a solid."""
    c = node.createOutputNode("clip")
    c.parmTuple("origin").set(origin)
    c.parmTuple("dir").set(direction)
    c.parm("clipop").set(keep)
    return c.createOutputNode("polycap")


def _disc(parent, radius, depth, arc=360.0):
    """A flat disc, or a pie of `arc` degrees from +x towards +z, extruded up by depth and centred on y."""
    c = parent.createNode("circle")
    c.parm("type").set("poly")
    c.parm("orient").set("zx")
    c.parm("radx").set(radius)
    c.parm("rady").set(radius)
    c.parm("divs").set(48)
    c.parm("arc").set("closedarc" if arc < 360 else "closed")
    if arc < 360:
        c.parm("beginangle").set(0)
        c.parm("endangle").set(arc)
    e = c.createOutputNode("polyextrude::2.0")
    e.parm("dist").set(depth)
    e.parm("outputback").set(1)
    x = e.createOutputNode("xform")
    x.parmTuple("t").set((0, -depth / 2, 0))
    return x


def _arc_band(parent, radius, arc, width, depth):
    """A flat band along an arc of `arc` degrees: a circle arc swept as a ribbon, then extruded."""
    c = parent.createNode("circle")
    c.parm("type").set("poly")
    c.parm("orient").set("zx")
    c.parm("radx").set(radius)
    c.parm("rady").set(radius)
    c.parm("divs").set(48)
    c.parm("arc").set("openarc")
    c.parm("beginangle").set(0)
    c.parm("endangle").set(arc)
    s = c.createOutputNode("sweep::2.0")
    s.parm("surfaceshape").set("ribbon")
    s.parm("width").set(width)
    s.parm("upvectortype").set("y")
    e = s.createOutputNode("polyextrude::2.0")
    e.parm("dist").set(depth)
    e.parm("outputback").set(1)
    return e


def _profile(parent, quads, depth):
    """Convex quads drawn in the xy plane, as (x, y) corner lists, extruded by depth along z."""
    code = []
    for quad in quads:
        corners = ["addpoint(0, set(%r, %r, 0.0))" % (float(x), float(y)) for x, y in quad]
        code.append("addprim(0, \"poly\", %s);" % ", ".join(corners))
    p = parent.createNode("attribwrangle")
    p.parm("class").set("detail")
    p.parm("snippet").set("\n".join(code) + "\n")    # vex: a list of corner quads is one primitive per quad from named corners; the Curve SOP draws ONE primitive a node, so each quad would be its own node and a merge - checked sop/curve, sop/add
    e = p.createOutputNode("polyextrude::2.0")
    e.parm("dist").set(depth)
    e.parm("outputback").set(1)
    return e


def _centred(node):
    """Moves a piece so its bounding box is centred on the origin."""
    x = node.createOutputNode("xform")
    x.parm("tx").setExpression("-centroid(opinputpath('.', 0), D_X)")
    x.parm("ty").setExpression("-centroid(opinputpath('.', 0), D_Y)")
    x.parm("tz").setExpression("-centroid(opinputpath('.', 0), D_Z)")
    return x


def _merge(parent, nodes):
    m = parent.createNode("merge")
    for i, n in enumerate(nodes):
        m.setInput(i, n)
    return m


def _frame(parent, outer, width, depth, y=0.0):
    """A square ring in the ground plane: four bars, `outer` wide, `width` thick."""
    o, w = outer, width
    return _merge(parent, [
        _box(parent, (o, depth, w), (0, y, o / 2 - w / 2)),
        _box(parent, (o, depth, w), (0, y, -o / 2 + w / 2)),
        _box(parent, (w, depth, o - 2 * w), (o / 2 - w / 2, y, 0)),
        _box(parent, (w, depth, o - 2 * w), (-o / 2 + w / 2, y, 0)),
    ])


def recipe(parent, kind):
    """The unit piece for one kind, as the last node of its SOP chain."""
    if kind == "tile_full":
        return _box(parent, (1, THIN, 1))
    if kind == "tile_half":
        return _centred(_disc(parent, 0.5, THIN, arc=180))
    if kind == "tile_quarter":
        return _centred(_disc(parent, 1.0, THIN, arc=90))
    if kind == "tile_diag":
        return _centred(_clip(_box(parent, (1, THIN, 1)), (0, 0, 0), (1, 0, 1)))
    if kind == "tile_stripes":
        return _merge(parent, [_box(parent, (0.125, THIN, 1), ((k - 1.5) * 0.25, 0, 0)) for k in range(4)])
    if kind == "disc":
        return _tube(parent, 0.5, 0.15)
    if kind == "glyph_bar":
        return _box(parent, (1, THIN, 0.3))
    if kind == "glyph_chevron":
        return _centred(_merge(parent, [_box(parent, (0.6, THIN, 0.18), (0, 0, 0.21), (0, 45, 0)),
                                        _box(parent, (0.6, THIN, 0.18), (0, 0, -0.21), (0, -45, 0))]))
    if kind == "glyph_pie":
        half = _disc(parent, 0.5, THIN, arc=135)
        other = _disc(parent, 0.5, THIN, arc=135).createOutputNode("xform")
        other.parm("ry").set(-135)
        return _centred(_merge(parent, [half, other]))    # two convex pies; one 270 degree polygon tears its cap
    if kind == "stripe":
        return _box(parent, (1, THIN, 0.16))
    if kind == "corner":
        return _centred(_merge(parent, [_box(parent, (1, THIN, 0.16), (0, 0, -0.42)), _box(parent, (0.16, THIN, 1), (-0.42, 0, 0))]))
    if kind == "ring":
        return _frame(parent, 1.0, 0.16, THIN)
    if kind == "rings":
        return _merge(parent, [_frame(parent, 1.0, 0.14, THIN), _frame(parent, 0.5, 0.14, THIN)])
    if kind == "bar_i":
        return _box(parent, (1, 0.3, 0.3))
    if kind == "bar_l":
        return _centred(_merge(parent, [_box(parent, (1, 0.3, 0.3)), _box(parent, (0.3, 0.3, 0.6), (0.35, 0, 0.45))]))
    if kind == "bar_t":
        return _centred(_merge(parent, [_box(parent, (1, 0.3, 0.3)), _box(parent, (0.3, 0.3, 0.6), (0, 0, 0.45))]))
    if kind == "bead":
        return _box(parent, (0.3, 0.3, 0.3))
    if kind == "cross":
        return _merge(parent, [_box(parent, (1, 0.3, 0.3)), _box(parent, (0.3, 0.3, 1))])
    if kind == "slab":
        return _box(parent, (1, 0.25, 1))
    if kind == "wedge":
        return _centred(_clip(_box(parent, (1, 0.6, 1)), (0, 0, 0), (1, 1, 0)))
    if kind == "crease":
        h, t = 0.14, 0.06
        return _centred(_profile(parent, [[(-0.5, 0), (0, h), (0, h - t), (-0.5, -t)], [(0, h), (0.5, 0), (0.5, -t), (0, h - t)]], 1.0))
    if kind == "sliver":
        return _box(parent, (1, 0.05, 0.15))
    if kind == "block":
        return _box(parent, (1, 1, 1))
    if kind == "bar":
        return _box(parent, (1, 0.35, 0.35))
    if kind == "rod":
        return _tube(parent, 0.12, 1, axis="x")
    if kind == "cylinder":
        return _tube(parent, 0.5, 1)
    if kind == "half_cylinder":
        return _centred(_clip(_tube(parent, 0.5, 1), (0, 0, 0), (1, 0, 0)))
    if kind == "half_disc":
        return _centred(_clip(_tube(parent, 0.5, 0.15), (0, 0, 0), (1, 0, 0)))
    if kind == "quarter_round":
        return _centred(_clip(_clip(_tube(parent, 0.5, 1), (0, 0, 0), (1, 0, 0)), (0, 0, 0), (0, 0, 1)))
    if kind == "cell_tall":
        return _box(parent, (0.6, 1, 0.6))
    if kind == "cell_flat":
        return _box(parent, (0.9, 0.3, 0.9))
    if kind == "frame":
        return _frame(parent, 1.0, 0.15, 0.15)
    if kind == "frame_stack":
        return _centred(_merge(parent, [_frame(parent, 1.0, 0.15, 0.15), _frame(parent, 0.7, 0.13, 0.15, y=0.15), _frame(parent, 0.4, 0.11, 0.15, y=0.3)]))
    if kind == "dash":
        return _box(parent, (0.6, 0.02, 0.08))
    if kind == "tick":
        return _box(parent, (0.25, 0.02, 0.06))
    if kind == "pennant":
        return _centred(_disc(parent, 0.45, 0.02, arc=50))
    if kind == "mark_dot":
        return _tube(parent, 0.12, 0.02)
    if kind == "sweep":
        return _centred(_arc_band(parent, 0.5, 90, 0.06, 0.02))
    if kind == "ray":
        return _box(parent, (1, 0.02, 0.02))
    if kind == "plane":
        return _box(parent, (1, 0.02, 1))
    if kind == "shard":
        return _centred(_clip(_box(parent, (1, 0.02, 1)), (0, 0, 0), (1, 0, 1)))
    if kind == "blade":
        return _box(parent, (1, 0.02, 0.12))
    if kind == "plate":
        return _tube(parent, 0.5, 0.02)
    raise ValueError("no recipe for piece kind %r" % kind)


def build(parent, kinds):
    """Builds every kind in `kinds` under `parent` and returns the merge that holds them all."""
    made = [_kind(recipe(parent, kind), kind) for kind in kinds]
    lib = _merge(parent, made)
    lib.setName("pieces")
    return lib
