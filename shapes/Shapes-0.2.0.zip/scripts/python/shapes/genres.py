"""The genres: what the Generator's Genre menu offers. Each has a number, a name, an alphabet of piece kinds the piece library carries, and a palette whose LAST color is the accent."""

MONO = ((0.08, 0.08, 0.08), (0.93, 0.92, 0.88), (0.60, 0.60, 0.60))
PRIMARY = ((0.16, 0.32, 0.72), (0.98, 0.80, 0.10), (0.10, 0.10, 0.10), (0.96, 0.95, 0.92), (0.86, 0.12, 0.10))
WARM = ((0.93, 0.45, 0.12), (0.62, 0.18, 0.12), (0.98, 0.80, 0.20), (0.15, 0.35, 0.30), (0.95, 0.92, 0.85))
SMALLHORN = ((0.10, 0.33, 0.33), (0.93, 0.62, 0.60), (0.06, 0.45, 0.35), (0.55, 0.42, 0.13), (0.10, 0.20, 0.55),
             (0.85, 0.85, 0.35), (0.75, 0.85, 0.80), (0.62, 0.55, 0.45), (0.35, 0.60, 0.65), (0.86, 0.22, 0.10))
MEHRETU = ((0.05, 0.05, 0.05), (0.16, 0.32, 0.72), (0.86, 0.12, 0.10), (0.95, 0.50, 0.10), (0.25, 0.75, 0.85),
           (0.10, 0.55, 0.35), (0.98, 0.80, 0.10), (0.90, 0.35, 0.55), (0.98, 0.98, 0.96))

GENRES = {
    "F01": dict(number=1, name="Tile alphabet", palette=MONO,
                kinds=("tile_full", "tile_half", "tile_quarter", "tile_diag", "tile_stripes")),
    "F02": dict(number=2, name="Glyph on field", palette=MONO,
                kinds=("disc", "glyph_bar", "glyph_chevron", "glyph_pie", "tile_full", "tile_half")),
    "F03": dict(number=3, name="Stripe mazes", palette=MONO,
                kinds=("stripe", "corner", "ring", "rings")),
    "F05": dict(number=5, name="Bar stacks and lattices", palette=PRIMARY,
                kinds=("bar_i", "bar_l", "bar_t", "bead", "cross")),
    "F06": dict(number=6, name="Slabs and folds", palette=PRIMARY,
                kinds=("slab", "wedge", "crease", "sliver")),
    "F09": dict(number=9, name="Block assemblies", palette=SMALLHORN,
                kinds=("block", "slab", "bar", "rod", "cylinder", "half_cylinder", "disc", "half_disc", "quarter_round")),
    "F10": dict(number=10, name="Repeated cells", palette=WARM,
                kinds=("block", "cell_tall", "cell_flat", "cylinder")),
    "F11": dict(number=11, name="Nested frames", palette=WARM,
                kinds=("frame", "frame_stack", "tile_full", "slab")),
    "F13": dict(number=13, name="Mark swarms and sweeps", palette=MEHRETU,
                kinds=("dash", "tick", "pennant", "mark_dot", "sweep", "ray", "rod", "plane", "shard", "blade", "plate")),
}

ORDER = ("F01", "F02", "F03", "F05", "F06", "F09", "F10", "F11", "F13")    # the menu's order, by number
DEFAULT = "F09"    # a fresh node's genre
FLAT = ("F01", "F02", "F03", "F11", "F13")    # the styles Thickness and Primitive Type reach
SOLID_IN_FLAT = ("rod", "frame_stack", "slab")    # not flat plates, so they stay as built


def menu():
    """(tokens, labels) for the Clone style menu, in ORDER: the names alone, the F numbers stay in the code and the notes."""
    return tuple(ORDER), tuple(GENRES[g]["name"] for g in ORDER)


def all_kinds():
    """Every piece kind any genre asks for, once, in a stable order."""
    seen = []
    for g in ORDER:
        for k in GENRES[g]["kinds"]:
            if k not in seen:
                seen.append(k)
    return tuple(seen)


def flat_kinds():
    """Every flat plate a flat style uses, in the order all_kinds() gives them."""
    flat = {k for g in FLAT for k in GENRES[g]["kinds"]}
    return tuple(k for k in all_kinds() if k in flat and k not in SOLID_IN_FLAT)
