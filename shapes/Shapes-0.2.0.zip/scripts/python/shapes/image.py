"""What the two image nodes are BUILT from: the menus their Color Space, Method, Fill and Strokes read, and the cell layout over a picture. Both nodes now lay their own cells out in a detail wrangle, so nothing here runs at cook time."""

COLOR_MENU = (("srgb", "sRGB picture"), ("linear", "Linear picture"), ("ocio", "OpenColorIO"))
METHOD_MENU = (("regions", "Regions"), ("fit", "Fit"))
FILL_MENU = (("outline", "Outline"), ("paths", "Paths"), ("both", "Outline and paths"))
MARK_MENU = (("dark", "Dark on light"), ("light", "Light on dark"), ("both", "Either way"))
FIT_WIDTH = 128    # the fit runs on the picture reduced to this many pixels across


def rows_of(cols, aspect):
    """How many rows of square cells `cols` columns make over a picture of that aspect."""
    return max(1, int(round(cols / aspect)))


def layout(width, height, density, detail, limit=0):
    """The cell grid for a picture of width by height pixels: `density` cells across, square cells, read at `detail` pixels across at most, and coarser where `limit` is fewer cells than the density asks for."""
    aspect = width / float(height)
    asked = max(1, int(density))
    cols = asked
    while limit > 0 and cols > 1 and cols * rows_of(cols, aspect) > limit:
        cols -= 1    # a limit thins the whole picture down to a coarser grid; it never crops it to the first rows
    rows = rows_of(cols, aspect)
    short = float(min(width, height))
    resx = min(int(width), max(8, int(detail)))
    resy = max(1, int(round(resx / aspect)))
    return {
        "cols": cols,
        "rows": rows,
        "asked": asked * rows_of(asked, aspect),
        "aspect": aspect,
        "cellw": (width / short) / cols,    # Copernicus local units: the picture's short side is 1
        "cellh": (height / short) / rows,
        "resx": resx,
        "resy": resy,
        "npx": resx / float(cols),    # a cell's width in working pixels, what the edge amount is measured against
    }


