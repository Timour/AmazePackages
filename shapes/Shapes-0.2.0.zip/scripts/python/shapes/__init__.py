"""Shapes - a shape generator for Houdini. The package behind the HDAs in the Shapes TAB submenu."""

APP_VERSION = "0.2.0"    # the RELEASED version, MAJOR.MINOR.PATCH
