"""Cloner Shapes: each shape a graph of discs, its outline walked round the branches between them."""

import math
import random

import hou

TAU = math.pi * 2.0
STYLE_MENU = (("blob", "Blob"), ("drop", "Drop"), ("star", "Star"), ("tree", "Tree"), ("spiral", "Spiral"), ("seaweed", "Seaweed"))
STYLES = tuple(token for token, _ in STYLE_MENU)
DEFAULT = "blob"
MIN_GAP = math.radians(45.0)    # the narrowest angle allowed between two branches leaving one disc
MARGIN = 1.5    # how far apart two discs that are not joined are kept, in the sum of their radii
MAX_REACH = 3.0    # how far a branch extremum may sit from its disc's centre, in radii, whatever the angle asks for
BEZIER_STEPS = 12    # points sampled along each branch edge
ARC_STEP = math.radians(12.0)
MAX_BRANCHES = 6    # the most branches a generated disc is given


def _norm(x, y):
    d = math.hypot(x, y)
    return (x / d, y / d) if d > 1e-12 else (1.0, 0.0)


def _wobble(rng, variation, width=0.5):
    """A multiplier around 1 whose spread is Variation."""
    return 1.0 + variation * width * rng.uniform(-1.0, 1.0)


def _clear(nodes, edges, u, v, radius, parent):
    """Whether a disc placed here has room: clear of the discs one branch further along its own, and MARGIN clear of everything beyond them, since two branches that cross make an outline that crosses."""
    close = {b for a, b in edges if a == parent} | {a for a, b in edges if b == parent}
    for n, node in enumerate(nodes):
        if n == parent:
            continue
        if math.hypot(u - node[0], v - node[1]) < (radius + node[2]) * (1.0 if n in close else MARGIN):
            return False
    return True


def _spread(count):
    """How far a direction may be jittered off its even share of the circle and still leave MIN_GAP to its neighbours."""
    return max(0.0, (TAU / count - MIN_GAP) / 2.0)


def _blob(rng, discs, variation):
    """A hub with lobes round it, the overflow hung off the lobes and pointing outwards: the paper's simplest graph, discs joined to the first."""
    nodes, edges, ring = [[0.0, 0.0, 1.0, 1.0]], [], []
    lobes = max(1, min(discs - 1, MAX_BRANCHES))
    base, jitter = rng.uniform(0.0, TAU), _spread(max(2, lobes))
    for n in range(lobes):
        angle = base + TAU * n / lobes + rng.uniform(-jitter, jitter)
        radius = rng.uniform(0.55, 0.95) * _wobble(rng, variation)
        step = (1.0 + radius) * rng.uniform(0.62, 0.92)    # the lobes sink into the hub, so a blob comes out round
        u, v = step * math.cos(angle), step * math.sin(angle)
        if _clear(nodes, edges, u, v, radius, 0):
            nodes.append([u, v, radius, 1.0])
            edges.append((0, len(nodes) - 1))
            ring.append((len(nodes) - 1, angle))
    while ring and len(nodes) < discs:
        grown = []
        for parent, outward in ring:
            if len(nodes) >= discs:
                break
            for attempt in range(4):    # a lobe with no room is asked for again smaller and further out before the ring gives up on it and the shape stops growing
                angle = outward + rng.uniform(-0.5, 0.5)    # the later rings keep pointing out, so they cannot wrap back over the hub
                radius = nodes[parent][2] * rng.uniform(0.50, 0.85) * _wobble(rng, variation) * 0.7 ** attempt
                step = (nodes[parent][2] + radius) * rng.uniform(0.62, 0.92) * 1.2 ** attempt
                u, v = nodes[parent][0] + step * math.cos(angle), nodes[parent][1] + step * math.sin(angle)
                if _clear(nodes, edges, u, v, radius, parent):
                    nodes.append([u, v, radius, 1.0])
                    edges.append((parent, len(nodes) - 1))
                    grown.append((len(nodes) - 1, angle))
                    break
        if not grown:
            break
        ring = grown
    return nodes, edges


def _chain(rng, discs, variation, taper, turn, wobble=0.0, shrink=1.0):
    """A run of discs each joined to the one before, `turn` giving the heading change at step m and `shrink` a factor per step on top of the taper; the run stops where the next disc would run into an earlier one."""
    heading, nodes, edges = rng.uniform(0.0, TAU), [], []
    u = v = 0.0
    for m in range(discs):
        t = m / float(max(1, discs - 1))
        radius = max(0.01, shrink ** m * (1.0 - t * taper) * (_wobble(rng, variation) if m else 1.0) * (1.0 + wobble * math.sin(m * 1.7)))    # a floor low enough to stay under the shrink at the longest run, since a chain that stops shrinking winds back into itself
        if m:
            heading += turn(m, rng)
            for attempt in range(3):    # a disc with no room is pushed further along the heading before the run gives up, since a run that stops draws the same shape at every count above it
                step = (nodes[-1][2] + radius) * rng.uniform(0.62, 0.95) * 1.3 ** attempt
                u, v = nodes[-1][0] + step * math.cos(heading), nodes[-1][1] + step * math.sin(heading)
                if _clear(nodes, edges, u, v, radius, m - 1):
                    break
            else:
                break
            edges.append((m - 1, m))
        nodes.append([u, v, radius, 1.0])
    return nodes, edges


def _drop(rng, discs, variation):
    """A big disc and a small one apart, with the discs between them when more are asked for: the paper's drop."""
    return _chain(rng, discs, variation, 0.80, lambda m, r: r.uniform(-0.16, 0.16))


def _seaweed(rng, discs, variation):
    """A chain whose heading swings from side to side: the paper's seaweed."""
    amp, freq, phase = rng.uniform(0.30, 0.55), rng.uniform(0.7, 1.4), rng.uniform(0.0, TAU)
    return _chain(rng, discs, variation, 0.45, lambda m, r: amp * math.sin(phase + m * freq) + r.uniform(-0.08, 0.08), wobble=0.18)


def _spiral(rng, discs, variation):
    """A chain that curls one way, the discs shrinking geometrically as it winds in: the paper's spiral, whose windings clear each other only while each turn is wider than the discs it passes over."""
    way, angle, shrink = rng.choice((1.0, -1.0)), rng.uniform(0.34, 0.46) * (1.0 - 0.45 * variation), rng.uniform(0.86, 0.90)    # a winding is fifteen discs and more where Variation makes them uneven, since each one has to clear the winding under it
    return _chain(rng, discs, variation, 0.0, lambda m, r: way * angle, shrink=shrink)


def _star(rng, discs, variation):
    """A hub with thin arms of shrinking discs leaving it: the paper's starfish. The discs asked for are dealt out one to each arm in turn, so the first few open new arms and every one after lengthens one."""
    arms = max(1, min(rng.randint(3, 7), int(TAU / MIN_GAP), (discs - 1) // 2))    # two discs to an arm before another arm is opened, since a single disc on the hub is a lobe and reads as a blob
    nodes, edges, base = [[0.0, 0.0, 1.0, 1.0]], [], rng.uniform(0.0, TAU)
    jitter = _spread(arms)
    tips = [[0, 1.0, base + TAU * arm / arms + rng.uniform(-jitter, jitter)] for arm in range(arms)]
    growing = list(range(arms))
    while growing and len(nodes) < discs:
        for arm in list(growing):
            if len(nodes) >= discs:
                break
            parent, parent_r, heading = tips[arm]
            radius = parent_r * rng.uniform(0.40, 0.62) * _wobble(rng, variation)
            step = (parent_r + radius) * rng.uniform(1.05, 1.45)    # the arms are drawn out, so the branch between two discs is a narrow waist
            u, v = nodes[parent][0] + step * math.cos(heading), nodes[parent][1] + step * math.sin(heading)
            if not _clear(nodes, edges, u, v, radius, parent):
                growing.remove(arm)
                continue
            nodes.append([u, v, radius, 1.0])
            edges.append((parent, len(nodes) - 1))
            tips[arm] = [len(nodes) - 1, radius, heading + rng.uniform(-0.20, 0.20)]
    return nodes, edges


def _tree(rng, discs, variation):
    """A root that splits, the radii and the steps shrinking with depth: the paper's tree."""
    nodes, edges = [[0.0, 0.0, 1.0, 1.0]], []
    front = [(0, rng.uniform(0.0, TAU), 1.0)]
    while front and len(nodes) < discs:
        parent, heading, parent_r = front.pop(0)
        kids = 2 if (len(nodes) + 1 < discs and rng.random() < 0.6) else 1
        spread = rng.uniform(0.45, 0.75)
        for kid in range(kids):
            angle = heading + (spread * (2 * kid - 1) if kids > 1 else rng.uniform(-0.24, 0.24))
            radius = parent_r * rng.uniform(0.58, 0.78) * _wobble(rng, variation)
            step = (parent_r + radius) * rng.uniform(0.95, 1.35)
            u, v = nodes[parent][0] + step * math.cos(angle), nodes[parent][1] + step * math.sin(angle)
            if not _clear(nodes, edges, u, v, radius, parent):
                continue
            nodes.append([u, v, radius, 1.0])
            edges.append((parent, len(nodes) - 1))
            front.append((len(nodes) - 1, angle, radius))
    return nodes, edges


GRAPHS = {"blob": _blob, "drop": _drop, "star": _star, "tree": _tree, "spiral": _spiral, "seaweed": _seaweed}


def _extremum(node, from_angle, to_angle, smooth):
    """The branch extremum in the wedge running counterclockwise from one branch direction to the next: where the disc's two tangent lines along those branches meet, drawn back towards the centre when the disc is smooth."""
    beta = max(((to_angle - from_angle) % TAU) / 2.0, 1e-6)
    sine = max(math.sin(beta), 1e-4)
    reach = min(1.0 / sine if smooth <= 0.0 else 1.0 / math.sqrt(sine), MAX_REACH)
    alpha = from_angle + beta
    return (node[0] + node[2] * reach * math.cos(alpha), node[1] + node[2] * reach * math.sin(alpha))


def _tangent(point, node, along):
    """The unit vector at an extremum, perpendicular to that disc's angle bisector and pointing the way the edge runs."""
    bisector = _norm(point[0] - node[0], point[1] - node[1])
    t = (-bisector[1], bisector[0])
    return t if t[0] * along[0] + t[1] * along[1] >= 0.0 else (-t[0], -t[1])


def _bezier(start, start_node, start_s, end, end_node, end_s, steps):
    """One outer edge of a branch as a cubic whose end tangents run perpendicular to each disc's angle bisector, a third of the chord long at smoothness 1 and nothing at 0, sampled without its last point."""
    dx, dy = end[0] - start[0], end[1] - start[1]
    span = math.hypot(dx, dy)
    if span < 1e-9:
        return [start]
    along = (dx / span, dy / span)
    ta, tb = _tangent(start, start_node, along), _tangent(end, end_node, along)
    q = (start[0] + start_s * span / 3.0 * ta[0], start[1] + start_s * span / 3.0 * ta[1])
    qq = (end[0] - end_s * span / 3.0 * tb[0], end[1] - end_s * span / 3.0 * tb[1])
    out = []
    for n in range(steps):
        t = n / float(steps)
        m = 1.0 - t
        a, b, c, d = m * m * m, 3.0 * m * m * t, 3.0 * m * t * t, t * t * t
        out.append((a * start[0] + b * q[0] + c * qq[0] + d * end[0], a * start[1] + b * q[1] + c * qq[1] + d * end[1]))
    return out


def _arc(node, start, end):
    """The cap on a disc with one branch: its circle counterclockwise from one extremum to the other, without its last point."""
    a0 = math.atan2(start[1] - node[1], start[0] - node[0])
    span = (math.atan2(end[1] - node[1], end[0] - node[0]) - a0) % TAU
    steps = max(2, int(math.ceil(span / ARC_STEP)))
    return [(node[0] + node[2] * math.cos(a0 + span * n / steps), node[1] + node[2] * math.sin(a0 + span * n / steps)) for n in range(steps)]


def outline(nodes, edges, smoothness, steps=BEZIER_STEPS):
    """The shape's boundary as one closed list of (u, v), counterclockwise: an edge along every branch side, a cap at every leaf, walked once round the graph."""
    if not edges:
        node = nodes[0]
        return [(node[0] + node[2] * math.cos(TAU * n / 32), node[1] + node[2] * math.sin(TAU * n / 32)) for n in range(32)]
    neighbours, angles = [[] for _ in nodes], {}
    for a, b in edges:
        neighbours[a].append(b)
        neighbours[b].append(a)
    for k, near in enumerate(neighbours):
        for i in near:
            angles[(k, i)] = math.atan2(nodes[i][1] - nodes[k][1], nodes[i][0] - nodes[k][0]) % TAU
        near.sort(key=lambda i: angles[(k, i)])
    place = {(k, i): n for k, near in enumerate(neighbours) for n, i in enumerate(near)}
    smooth = [smoothness * node[3] for node in nodes]

    def side(k, i, step):
        """The extremum on one side of the branch k to i, at the disc k: step +1 counterclockwise of it, -1 clockwise."""
        near = neighbours[k]
        if len(near) == 1:
            angle = angles[(k, i)] + step * math.pi / 2.0
            return (nodes[k][0] + nodes[k][2] * math.cos(angle), nodes[k][1] + nodes[k][2] * math.sin(angle))
        other = near[(place[(k, i)] + step) % len(near)]
        pair = (i, other) if step > 0 else (other, i)
        return _extremum(nodes[k], angles[(k, pair[0])], angles[(k, pair[1])], smooth[k])

    points, here, start = [], (edges[0][0], edges[0][1]), (edges[0][0], edges[0][1])
    for _ in range(2 * len(edges)):
        k, i = here
        begin, end = side(k, i, -1), side(i, k, 1)
        points.extend(_bezier(begin, nodes[k], smooth[k], end, nodes[i], smooth[i], steps))
        if len(neighbours[i]) == 1:
            points.extend(_arc(nodes[i], end, side(i, k, -1)))
            here = (i, k)
        else:
            here = (i, neighbours[i][(place[(i, k)] + 1) % len(neighbours[i])])
        if here == start:
            break
    return points


def build(count, seed, style, variation, discs, smoothness):
    """Every shape as (points, kind) in (u, v), about one unit across and centred on the origin."""
    kind = style if style in GRAPHS else DEFAULT
    shapes = []
    for n in range(count):
        rng = random.Random("%d:%d:%s" % (seed, n, kind))
        nodes, edges = GRAPHS[kind](rng, discs, variation)
        points = outline(nodes, edges, smoothness)
        lo_u, hi_u = min(p[0] for p in points), max(p[0] for p in points)
        lo_v, hi_v = min(p[1] for p in points), max(p[1] for p in points)
        scale = max(0.05, _wobble(rng, variation, 0.7)) / max(hi_u - lo_u, hi_v - lo_v, 1e-6)
        shapes.append(([((p[0] - (lo_u + hi_u) / 2.0) * scale, (p[1] - (lo_v + hi_v) / 2.0) * scale) for p in points], kind))
    return shapes


def cook(node):
    """The Python SOP: the shapes as closed polygons on the ground, one connected piece each, carrying the style and its number in `name`."""
    asset = node.parent()
    geo = node.geometry()
    geo.clear()
    shapes = build(max(1, asset.parm("variants").eval()), asset.parm("seed").eval(), asset.parm("shapestyle").evalAsString(),
                   asset.parm("variation").eval(), max(2, asset.parm("discs").eval()), asset.parm("smoothness").eval())
    geo.addAttrib(hou.attribType.Prim, "name", "")
    positions, runs = [], []
    for points, kind in shapes:
        runs.append((len(positions), len(points), kind))
        positions.extend((u, 0.0, v) for u, v in points)    # the shapes lie on the ground; a counterclockwise outline written this way normals up, Houdini winding a front face clockwise. Plain tuples, not hou.Vector3: two thirds of the cook was the boxing, and the answer is bit-identical over 137 784 values
    created = geo.createPoints(positions)
    geo.createPolygons([created[at:at + many] for at, many, _ in runs], True)
    geo.setPrimStringAttribValues("name", ["%s_%d" % (kind, n + 1) for n, (_, _, kind) in enumerate(runs)])
