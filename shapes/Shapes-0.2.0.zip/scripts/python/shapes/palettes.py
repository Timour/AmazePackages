"""The Curated palettes: the genre's own first, then every Amaze palette with two or more colors, read from the Amaze library's gradients.json when this machine has one."""

import json
import os
import sys

GENRE = "genre"    # the token for the genre's own palette

_cache = {"path": None, "stamp": None, "rows": []}


def amaze_settings_path():
    """Amaze's settings file, where its library folder is recorded, per platform."""
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Preferences/Amaze/settings.json")
    if sys.platform.startswith("win"):
        return os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "Amaze", "settings.json")
    return os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "Amaze", "settings.json")


def gradients_path():
    """The gradients.json of the Amaze library this machine points at, or None."""
    override = os.environ.get("SHAPES_GRADIENTS")
    if override:
        return override
    try:
        with open(amaze_settings_path(), encoding="utf-8") as fh:
            directory = json.load(fh).get("directory") or ""
    except (OSError, ValueError):
        return None
    if not directory:
        return None
    path = os.path.join(os.path.expanduser(directory), "gradients.json")
    return path if os.path.exists(path) else None


def _hex_to_rgb(text):
    text = text.strip().lstrip("#")
    if len(text) != 6:
        return None
    try:
        return tuple(int(text[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    except ValueError:
        return None


def load(path):
    """[(id, label, [(r, g, b), ...]), ...] for every palette in a gradients.json with two or more colors."""
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    rows = data.get("assets") if isinstance(data, dict) else data
    if isinstance(rows, dict):
        rows = list(rows.values())
    out = []
    for row in rows or []:
        colors = [c for c in (_hex_to_rgb(str((entry or {}).get("hex", ""))) for entry in row.get("colors") or []) if c]
        if len(colors) < 2:
            continue
        category = (row.get("categories") or [""])[0]
        label = "%s · %s" % (category, row.get("name") or row.get("id")) if category else str(row.get("name") or row.get("id"))
        out.append((str(row.get("id")), label, colors))
    out.sort(key=lambda item: item[1].lower())
    return out


def palettes():
    """The Amaze palettes, cached against the file's modification time; empty without an Amaze library."""
    path = gradients_path()
    if path is None:
        return []
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        return []
    if _cache["path"] != path or _cache["stamp"] != stamp:
        try:
            _cache["rows"] = load(path)
        except (OSError, ValueError):
            _cache["rows"] = []
        _cache["path"], _cache["stamp"] = path, stamp
    return _cache["rows"]


def menu():
    """The flat token, label, token, label list a Houdini menu script returns."""
    items = [GENRE, "Style's own"]
    for token, label, _ in palettes():
        items += [token, label]
    return items


def colors(token):
    """The color list for a menu token, or None for the genre's own or an unknown token."""
    if token == GENRE:
        return None
    for candidate, _, rgb in palettes():
        if candidate == token:
            return rgb
    return None
