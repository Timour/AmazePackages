"""A genre as a tree of nodes in the Alvarez form (shape kind, distribution, size and turn, inclusion and exclusion, color slot), laid out on the field by seed. compose() lays it on a bare field, compose_on() over a picture's found shapes; the Image curves node's rows cook calls them."""

import math
import random

import hou

from shapes import genres


def node(kinds, distribution="random", count=12, size=(0.1, 0.3), squeeze=(1.0, 1.0), rotation=(0.0,), free=0.0,
         inside=True, exclusive=True, slot="random", children=(), empty=0.0):
    """One node of a tree: `count` shapes (cells across for regular), `size` as a share of the parent's short side, `squeeze` width over length, `rotation` choices in degrees plus `free` jitter, `inside` the parent, `exclusive` of siblings, a color `slot` rule, `children` laid inside each shape, `empty` the share of places left bare."""
    return dict(kinds=tuple(kinds), distribution=distribution, count=count, size=tuple(size), squeeze=tuple(squeeze), rotation=tuple(rotation),
                free=free, inside=inside, exclusive=exclusive, slot=slot, children=tuple(children), empty=empty)


TREES = {
    "F01": [node(("tile_full", "tile_half", "tile_quarter", "tile_diag", "tile_stripes"), "regular", count=8, size=(0.92, 0.92), rotation=(0, 90, 180, 270), exclusive=False, empty=0.12)],
    "F02": [node(("disc", "glyph_bar", "glyph_chevron", "glyph_pie"), "random", count=1, size=(0.4, 0.55), rotation=(0, 90), slot="accent"),
            node(("tile_full", "tile_half"), "regular", count=6, size=(0.55, 0.55), rotation=(0, 90), exclusive=False, empty=0.65)],
    "F03": [node(("stripe", "corner", "ring", "rings"), "regular", count=7, size=(0.96, 0.96), rotation=(0, 90, 180, 270), exclusive=False)],
    "F05": [node(("bar_i", "bar_l", "bar_t", "cross"), "regular", count=5, size=(0.8, 0.8), rotation=(0, 90), exclusive=False, empty=0.1),
            node(("bead",), "random", count=8, size=(0.1, 0.16))],
    "F06": [node(("slab", "wedge", "crease", "sliver"), "random", count=7, size=(0.35, 0.7), squeeze=(0.25, 0.6), free=25, inside=False, exclusive=False)],
    "F09": [node(("block", "slab", "bar", "rod", "cylinder", "half_cylinder", "disc", "half_disc", "quarter_round"), "random", count=16, size=(0.1, 0.28), squeeze=(0.5, 1.0), rotation=(0, 90))],
    "F10": [node(("block", "cell_tall", "cell_flat", "cylinder"), "regular", count=9, size=(0.72, 0.72), exclusive=False, empty=0.08)],
    "F11": [node(("frame",), "random", count=5, size=(0.22, 0.42),
                 children=[node(("frame", "tile_full"), "random", count=1, size=(0.55, 0.7), slot="depth",
                                children=[node(("frame", "slab"), "random", count=1, size=(0.45, 0.6), slot="accent")])])],
    "F13": [node(("sweep", "ray"), "random", count=4, size=(0.6, 1.1), squeeze=(0.06, 0.15), free=180, inside=False, exclusive=False, slot="accent"),
            node(("dash", "tick", "pennant", "mark_dot"), "random", count=90, size=(0.04, 0.1), squeeze=(0.2, 0.6), free=180, exclusive=False)],
}


def corners(shape):
    c, s = math.cos(math.radians(shape["angle"])), math.sin(math.radians(shape["angle"]))
    hx, hz = shape["length"] / 2.0, shape["width"] / 2.0
    return [(shape["x"] + dx * c - dz * s, shape["z"] + dx * s + dz * c) for dx, dz in ((-hx, -hz), (hx, -hz), (hx, hz), (-hx, hz))]


def _axes(shape):
    a = math.radians(shape["angle"])
    return [(math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))]


def overlaps(a, b):
    """Whether two oriented rectangles share any area (the separating axis test)."""
    ca, cb = corners(a), corners(b)
    for ax, az in _axes(a) + _axes(b):
        pa = [x * ax + z * az for x, z in ca]
        pb = [x * ax + z * az for x, z in cb]
        if max(pa) <= min(pb) or max(pb) <= min(pa):
            return False
    return True


def inside(child, parent):
    """Whether every corner of the child lies in the parent rectangle."""
    a = math.radians(parent["angle"])
    c, s = math.cos(a), math.sin(a)
    for x, z in corners(child):
        dx, dz = x - parent["x"], z - parent["z"]
        u, v = dx * c + dz * s, -dx * s + dz * c
        if abs(u) > parent["length"] / 2.0 + 1e-9 or abs(v) > parent["width"] / 2.0 + 1e-9:
            return False
    return True


def _shape(rnd, spec, parent, kind, x, z, length, depth, angle=None):
    width = length * rnd.uniform(*spec["squeeze"])
    if angle is None:
        angle = rnd.choice(spec["rotation"]) + rnd.uniform(-spec["free"], spec["free"])
    return dict(kind=kind, x=x, z=z, length=length, width=width, angle=parent["angle"] + angle, depth=depth, slot=spec["slot"])


def _place(rnd, spec, parent, siblings, kind, length, depth, tries=40):
    """A shape of the given length dropped at random in the parent, kept inside it and clear of its siblings as the node asks; None when no place is found."""
    for _ in range(tries):
        u = rnd.uniform(-parent["length"] / 2.0, parent["length"] / 2.0)
        v = rnd.uniform(-parent["width"] / 2.0, parent["width"] / 2.0)
        a = math.radians(parent["angle"])
        x, z = parent["x"] + u * math.cos(a) - v * math.sin(a), parent["z"] + u * math.sin(a) + v * math.cos(a)
        shape = _shape(rnd, spec, parent, kind, x, z, length, depth)
        if spec["inside"] and not inside(shape, parent):
            continue
        if spec["exclusive"] and any(overlaps(shape, other) for other in siblings):
            continue
        return shape
    return None


def lay(rnd, spec, parent, depth, density, space):
    """The shapes one node puts in one parent, by its distribution."""
    short = min(parent["length"], parent["width"])
    made = []
    empty = min(1.0, spec["empty"] + space)
    if spec["distribution"] == "regular":
        across = max(1, int(round(spec["count"] * math.sqrt(density))))
        cell = parent["length"] / across
        down = max(1, int(round(parent["width"] / cell)))
        a = math.radians(parent["angle"])
        for j in range(down):
            for i in range(across):
                if rnd.random() < empty:
                    continue
                u = -parent["length"] / 2.0 + (i + 0.5) * cell
                v = -parent["width"] / 2.0 + (j + 0.5) * (parent["width"] / down)
                x, z = parent["x"] + u * math.cos(a) - v * math.sin(a), parent["z"] + u * math.sin(a) + v * math.cos(a)
                made.append(_shape(rnd, spec, parent, rnd.choice(spec["kinds"]), x, z, cell * rnd.uniform(*spec["size"]), depth))
    elif spec["distribution"] == "contouring":
        perimeter = 2 * (parent["length"] + parent["width"])
        step = short * max(spec["size"]) / max(1e-6, math.sqrt(density))
        n = max(1, int(perimeter / step))
        a = math.radians(parent["angle"])
        for k in range(n):
            if rnd.random() < empty:
                continue
            t = (k + 0.5) / n * perimeter
            u, v, along = _on_perimeter(t, parent["length"], parent["width"])
            x, z = parent["x"] + u * math.cos(a) - v * math.sin(a), parent["z"] + u * math.sin(a) + v * math.cos(a)
            made.append(_shape(rnd, spec, parent, rnd.choice(spec["kinds"]), x, z, short * rnd.uniform(*spec["size"]), depth, angle=along))
    elif spec["distribution"] == "mondrian":
        cells = [dict(x=parent["x"], z=parent["z"], length=parent["length"], width=parent["width"], angle=parent["angle"])]
        for _ in range(max(0, int(round(spec["count"] * density)) - 1)):
            cell = cells.pop(rnd.randrange(len(cells)))
            cells.extend(_split(rnd, cell))
        for cell in cells:
            if rnd.random() < empty:
                continue
            made.append(dict(kind=rnd.choice(spec["kinds"]), x=cell["x"], z=cell["z"], length=cell["length"] * spec["size"][1], width=cell["width"] * spec["size"][1],
                             angle=cell["angle"], depth=depth, slot=spec["slot"]))
    else:
        for _ in range(max(0, int(round(spec["count"] * density * (1.0 - empty))))):
            shape = _place(rnd, spec, parent, made, rnd.choice(spec["kinds"]), short * rnd.uniform(*spec["size"]), depth)
            if shape is not None:
                made.append(shape)
    return made


def _on_perimeter(t, length, width):
    """A point at distance t along a rectangle's perimeter, in the rectangle's frame, and the edge's angle."""
    if t < length:
        return -length / 2.0 + t, -width / 2.0, 0.0
    t -= length
    if t < width:
        return length / 2.0, -width / 2.0 + t, 90.0
    t -= width
    if t < length:
        return length / 2.0 - t, width / 2.0, 0.0
    t -= length
    return -length / 2.0, width / 2.0 - t, 90.0


def _split(rnd, cell):
    along_length = cell["length"] >= cell["width"]
    f = rnd.uniform(0.3, 0.7)
    a = math.radians(cell["angle"])
    if along_length:
        l1, l2 = cell["length"] * f, cell["length"] * (1 - f)
        u1, u2 = -cell["length"] / 2.0 + l1 / 2.0, cell["length"] / 2.0 - l2 / 2.0
        return [dict(cell, x=cell["x"] + u * math.cos(a), z=cell["z"] + u * math.sin(a), length=l) for u, l in ((u1, l1), (u2, l2))]
    w1, w2 = cell["width"] * f, cell["width"] * (1 - f)
    v1, v2 = -cell["width"] / 2.0 + w1 / 2.0, cell["width"] / 2.0 - w2 / 2.0
    return [dict(cell, x=cell["x"] - v * math.sin(a), z=cell["z"] + v * math.cos(a), width=w) for v, w in ((v1, w1), (v2, w2))]


PICTURE_TREES = {    # what a genre lays inside and around each shape found in a picture
    "F01": [node(("tile_full", "tile_half", "tile_quarter", "tile_diag", "tile_stripes"), "regular", count=4, size=(0.92, 0.92), rotation=(0, 90, 180, 270), exclusive=False, empty=0.1)],
    "F02": [node(("disc", "glyph_bar", "glyph_chevron", "glyph_pie"), "random", count=1, size=(0.5, 0.7), rotation=(0, 90), slot="accent")],
    "F03": [node(("stripe", "corner", "ring", "rings"), "regular", count=4, size=(0.96, 0.96), rotation=(0, 90, 180, 270), exclusive=False)],
    "F05": [node(("bar_i", "bar_l", "bar_t", "cross"), "regular", count=3, size=(0.8, 0.8), rotation=(0, 90), exclusive=False),
            node(("bead",), "random", count=3, size=(0.15, 0.25))],
    "F06": [],
    "F09": [node(("block", "slab", "bar", "rod", "cylinder", "half_cylinder", "disc", "half_disc", "quarter_round"), "random", count=6, size=(0.15, 0.35), squeeze=(0.5, 1.0), rotation=(0, 90))],
    "F10": [node(("block", "cell_tall", "cell_flat", "cylinder"), "regular", count=3, size=(0.72, 0.72), exclusive=False)],
    "F11": [node(("frame",), "random", count=1, size=(0.6, 0.75), slot="depth",
                 children=[node(("frame", "tile_full"), "random", count=1, size=(0.5, 0.65), slot="accent")])],
    "F13": [node(("dash", "tick", "pennant", "mark_dot"), "contouring", size=(0.08, 0.14), squeeze=(0.2, 0.5), free=15, exclusive=False, empty=0.2)],
}

FIELD_TREES = {    # what a genre lays on the whole field over a picture
    "F13": [node(("sweep", "ray"), "random", count=3, size=(0.5, 0.9), squeeze=(0.05, 0.12), free=180, inside=False, exclusive=False, slot="accent")],
}


def _grow(rnd, specs, parent, depth, density, space, out, start):
    for spec in specs:
        for shape in lay(rnd, spec, parent, depth, density, space):
            shape["order"] = start + len(out)
            out.append(shape)
            if spec["children"]:
                _grow(rnd, spec["children"], shape, depth + 1, density, space, out, start)


def compose(genre_key, seed, field, density=1.0, space=0.0, aspect=1.0):
    """Every shape of a genre's tree on a field `field` wide and `field / aspect` deep, in drawing order: dicts with kind, x, z, length, width, angle, depth, slot, order."""
    rnd = random.Random(seed * 7919 + genres.GENRES[genre_key]["number"])
    root = dict(x=0.0, z=0.0, length=float(field), width=float(field) / aspect, angle=0.0)
    out = []
    _grow(rnd, TREES.get(genre_key, TREES["F09"]), root, 0, density, space, out, 0)
    return out


def compose_on(genre_key, seed, field, aspect, parents, density=1.0, space=0.0):
    """The genre over a picture's found shapes: its picture tree inside and around each parent (dicts with x, z, length, width, angle), its field tree on the whole field; the children only, ordered after the parents. With no parents, the genre's own tree on the field."""
    if not parents:
        return compose(genre_key, seed, field, density, space, aspect)
    rnd = random.Random(seed * 7919 + genres.GENRES[genre_key]["number"] + 17)
    root = dict(x=0.0, z=0.0, length=float(field), width=float(field) / aspect, angle=0.0)
    out = []
    for parent in parents:
        _grow(rnd, PICTURE_TREES.get(genre_key, ()), parent, 1, density, space, out, len(parents))
    _grow(rnd, FIELD_TREES.get(genre_key, ()), root, 0, density, space, out, len(parents))
    return out


