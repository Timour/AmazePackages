"""The Cloner's menus and the attributes its points come out carrying. The cook itself is shipped nodes and VEX inside the asset, built by tools/build-hda.py; nothing here runs while a point is being placed."""

COLOR_MENU = (("greyscale", "Greyscale"), ("random", "Random"), ("curated", "Curated"), ("input", "From points"))    # From points writes NOTHING: the clone keeps the color it arrived with, on whatever class it arrived on

FROM_POINTS = 3    # the default, and the one entry that paints nothing; it keeps its index so a saved scene reads the same setting

CLONES = "input"    # the Clone style menu's last entry, past every style: what is wired into the Clones input, spelled the way Shape spells its own

SHAPES = "shapes"    # Cloner Shapes: shapes the Cloner draws itself, cloned the way Input geometry is
PRIMITIVE_MENU = (("poly", "Polygon"), ("curve", "Curve"))    # Primitive Type; `poly` is Houdini's own token

SHAPE_MENU = (("grid", "Grid"), ("box", "Box"), ("sphere", "Sphere"), ("input", "Input geometry"))
FILL_MENU = (("auto", "Automatic"), ("points", "Points"), ("surface", "Surface"), ("volume", "Volume"))
ORIENT_MENU = (("given", "From the points"), ("random90", "Random, 90 degree steps"), ("fixed", "Fixed"), ("normal", "To normal"))
OUTPUT_MENU = (("packed", "Packed"), ("polygons", "Polygons"))

CONTRACT = ("P", "Cd", "pscale", "scale", "orient", "id", "name", "shape_falloff")    # Houdini's own placement names, and the piece as Copy to Points reads it; N and up ride through when the cloud has them

WORKING = ("shape_tone", "shape_accent", "shape_turn")    # what the chain writes for itself and takes off again before the copy

GIVEN = ("shape_kind", "shape_box", "shape_angle", "shape_slot")    # names of OURS a point may arrive with, honoured on the way in and gone on the way out; `kind` was read here too and is the artist's own, so it is neither read nor deleted
